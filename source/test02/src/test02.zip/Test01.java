package test02;

import java.util.Scanner;

public class Test01 {

	public static void main(String[] args) {
	//   학년(1 ~ 4)와 점수(0 ~ 100)을 입력 받아  60점 이상이면 합격, 60점 미만이면 불합격 메시지를 출력하시오. 
	//(단, 학년이 4학년이면서 점수가 80점 이상일 때는 ‘졸업입니다’ 를 학년이 4학년이지만 80점 미만일 때는 ‘재시험입니다’를 출력하시오.
		Scanner scanner = new Scanner(System.in);
		System.out.print("학년입력 > ");
		int num= scanner.nextInt();
		
		System.out.print("점수입력 > ");
		int jumsu = scanner.nextInt();
		
		switch(num){
		case 1:
			if(jumsu >=60) {
				System.out.println("합격");
			}else {
				System.out.println("불합격");
			}
			break;
			
		case 2:
			
			if(jumsu >=60) {
				System.out.println("합격");
			}else {
				System.out.println("불합격");
			}
			break;
			
		case 3:
			if(jumsu >=60) {
				System.out.println("합격");
			}else {
				System.out.println("불합격");
			}
			break;
		case 4:
			if(jumsu >=80) {
				System.out.println("졸업입니다.");
			}else {
				System.out.println("재시험입니다.");
			}
			break;
			
			default:
				System.out.println("잘못된 값입니다.");
				 System.exit(0);
				 
		}

	}

}
