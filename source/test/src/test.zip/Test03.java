package test;

public class Test03 {

	public static void main(String[] args) {
		// do-while 문 이용하여 a부터 z까지 출력하는 프로그램을 작성하시오.
				char i='a';
				
				do {
					System.out.print(i++ +" ");
				}while(i<='z');
			
				
	}

}
